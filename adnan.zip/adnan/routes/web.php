<?php

use Illuminate\Support\Facades\Route;
use Illuminate\Http\Request;
use Illuminate\Support\ViewErrorBag;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Route::get('/home', function(){
    return view('login');
});
Route::get('/coba/{id}', function($id){
    return view('coba', ['id'=>$id]);
});

Route::get('/biodata', function(){
    return view('biodata');
});

Route::post('/kirim', function(){
// $data = "nama:.$request->nama.
//         email:.$request->email.";


// // var_dump($request->nama);die();
// return view('jajal', ['data'=>$data]);
echo"1";
});