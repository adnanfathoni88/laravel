<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta http-equiv="X-UA-Compatible" content="IE=edge" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Biodata</title>
    </head>
    <body>
        <form action="/kirim" method="post">
            <?php echo csrf_field(); ?>
            <div>
                <label for="nama">Nama</label>
                <input type="text" name="nama" />
            </div>
            <div>
                <label for="email">email</label>
                <input type="text" name="email" />
            </div>
            <div>
                <input type="submit" value="kirim" />
            </div>
        </form>
    </body>
</html>
<?php /**PATH D:\21.01.4707\21.01.4707\adnan\resources\views/biodata.blade.php ENDPATH**/ ?>